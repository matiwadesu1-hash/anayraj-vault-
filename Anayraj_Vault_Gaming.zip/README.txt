ANAYRAJ VAULT — GAMING STUDY WEBSITE

Password: 121609

Open index.html in Google Chrome.
Upload only study files (PPT, PDF, DOC/DOCX, TXT, etc.).

This version stores files locally in the browser on the device.
For a public website, upload index.html to GitHub Pages or another static host.
